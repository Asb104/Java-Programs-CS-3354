package acctMgr.model;
/**
 * 
 * @author Andrew Baker
 *
 */
public enum AgentStatus {
	Running, Blocked, Paused, NA
}
