package acctMgr.model;
/**
 * 
 * @author Andrew Baker
 *
 */
public interface Model {
	public void notifyChanged(ModelEvent me);
}
