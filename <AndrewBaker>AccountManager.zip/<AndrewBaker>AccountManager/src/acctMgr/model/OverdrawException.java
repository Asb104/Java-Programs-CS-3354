package acctMgr.model;
import java.math.BigDecimal;
/**
 * 
 * @author Andrew Baker
 *
 */
public class OverdrawException extends Exception {
	OverdrawException(BigDecimal amt){
		super("Overdraw by " + amt);
	}
}
