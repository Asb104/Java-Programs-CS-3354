package acctMgr.model;

/**
 * 
 * @author Andrew Baker
 *
 */
public interface ModelListener {
	public void modelChanged(ModelEvent me);
}
