package acctMgr.view;

import javax.swing.*;

public class JFramePanel extends JPanel {
}
